#run "pip install -r requirements.txt" first after that install the tools if not already installed

#how to install tools?

# For Debian-based systems (install separately)
	#sudo apt-get install nmap
	#sudo apt-get install wapiti
	#sudo apt-get install gobuster
	#sudo apt-get install nuclei

# For MacOS (install separately)
	#brew install nmap
	#brew install wapiti
	#brew install gobuster
	#brew install nuclei
